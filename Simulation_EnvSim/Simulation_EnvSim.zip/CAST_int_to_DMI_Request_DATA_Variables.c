/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config R:/Repositories/modeling/model/Scade/System/OBU_PreIntegrations/Testbench_Integration/Simulation_EnvSim\kcg_s2c_config.txt
** Generation date: 2015-11-12T10:46:57
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "CAST_int_to_DMI_Request_DATA_Variables.h"

/* DATA::Variables::CAST_int_to_DMI_Request */
DMI_Request_T_DMI_Types_Pkg CAST_int_to_DMI_Request_DATA_Variables(
  /* DATA::Variables::CAST_int_to_DMI_Request::dmi_request_int */kcg_int dmi_request_int)
{
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else */
  static kcg_bool _36_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else */
  static kcg_bool _34_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else */
  static kcg_bool _32_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else */
  static kcg_bool _30_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else */
  static kcg_bool _28_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _26_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _24_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _22_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _20_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _18_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _16_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _14_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _12_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _10_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _8_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _6_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _4_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _2_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _1_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _3_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _5_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _7_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _9_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _11_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _13_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _15_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _17_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _19_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _21_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _23_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _25_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else::else::else */
  static kcg_bool _27_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else::else::else */
  static kcg_bool _29_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else::else::else */
  static kcg_bool _31_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else::else::else */
  static kcg_bool _33_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1::else::else */
  static kcg_bool _35_else_clock_IfBlock1;
  /* DATA::Variables::CAST_int_to_DMI_Request::IfBlock1 */
  static kcg_bool IfBlock1_clock;
  /* DATA::Variables::CAST_int_to_DMI_Request::dmi_reqest_ct */
  static DMI_Request_T_DMI_Types_Pkg dmi_reqest_ct;
  
  IfBlock1_clock = dmi_request_int == INT_DMI_Request_T_End_of_NTC_data_entry;
  if (IfBlock1_clock) {
    dmi_reqest_ct = ENUM_DMI_Request_T_End_of_NTC_data_entry;
  }
  else {
    _36_else_clock_IfBlock1 = dmi_request_int ==
      INT_DMI_Request_T_Hide_tunnel_stopping_information;
    if (_36_else_clock_IfBlock1) {
      dmi_reqest_ct = ENUM_DMI_Request_T_Hide_tunnel_stopping_information;
    }
    else {
      _35_else_clock_IfBlock1 = dmi_request_int ==
        INT_DMI_Request_T_Language_changed;
      if (_35_else_clock_IfBlock1) {
        dmi_reqest_ct = ENUM_DMI_Request_T_Language_changed;
      }
      else {
        _34_else_clock_IfBlock1 = dmi_request_int ==
          INT_DMI_Request_T_Level_entry_request;
        if (_34_else_clock_IfBlock1) {
          dmi_reqest_ct = ENUM_DMI_Request_T_Level_entry_request;
        }
        else {
          _33_else_clock_IfBlock1 = dmi_request_int ==
            INT_DMI_Request_T_Maintain_shunting;
          if (_33_else_clock_IfBlock1) {
            dmi_reqest_ct = ENUM_DMI_Request_T_Maintain_shunting;
          }
          else {
            _32_else_clock_IfBlock1 = dmi_request_int ==
              INT_DMI_Request_T_Non_leading;
            if (_32_else_clock_IfBlock1) {
              dmi_reqest_ct = ENUM_DMI_Request_T_Non_leading;
            }
            else {
              _31_else_clock_IfBlock1 = dmi_request_int ==
                INT_DMI_Request_T_Non_leading_exit;
              if (_31_else_clock_IfBlock1) {
                dmi_reqest_ct = ENUM_DMI_Request_T_Non_leading_exit;
              }
              else {
                _30_else_clock_IfBlock1 = dmi_request_int ==
                  INT_DMI_Request_T_NTC_data_entry_request;
                if (_30_else_clock_IfBlock1) {
                  dmi_reqest_ct = ENUM_DMI_Request_T_NTC_data_entry_request;
                }
                else {
                  _29_else_clock_IfBlock1 = dmi_request_int ==
                    INT_DMI_Request_T_Override_EOA;
                  if (_29_else_clock_IfBlock1) {
                    dmi_reqest_ct = ENUM_DMI_Request_T_Override_EOA;
                  }
                  else {
                    _28_else_clock_IfBlock1 = dmi_request_int ==
                      INT_DMI_Request_T_Override_route_unsuitability;
                    if (_28_else_clock_IfBlock1) {
                      dmi_reqest_ct =
                        ENUM_DMI_Request_T_Override_route_unsuitability;
                    }
                    else {
                      _27_else_clock_IfBlock1 = dmi_request_int ==
                        INT_DMI_Request_T_Radio_network_entry_aborted;
                      if (_27_else_clock_IfBlock1) {
                        dmi_reqest_ct =
                          ENUM_DMI_Request_T_Radio_network_entry_aborted;
                      }
                      else {
                        _26_else_clock_IfBlock1 = dmi_request_int ==
                          INT_DMI_Request_T_Remove_VBC_request;
                        if (_26_else_clock_IfBlock1) {
                          dmi_reqest_ct = ENUM_DMI_Request_T_Remove_VBC_request;
                        }
                        else {
                          _25_else_clock_IfBlock1 = dmi_request_int ==
                            INT_DMI_Request_T_Request_for_Adhesion_factor_data;
                          if (_25_else_clock_IfBlock1) {
                            dmi_reqest_ct =
                              ENUM_DMI_Request_T_Request_for_Adhesion_factor_data;
                          }
                          else {
                            _24_else_clock_IfBlock1 = dmi_request_int ==
                              INT_DMI_Request_T_Request_for_radio_network_entry;
                            if (_24_else_clock_IfBlock1) {
                              dmi_reqest_ct =
                                ENUM_DMI_Request_T_Request_for_radio_network_entry;
                            }
                            else {
                              _23_else_clock_IfBlock1 = dmi_request_int ==
                                INT_DMI_Request_T_Request_for_SR_data;
                              if (_23_else_clock_IfBlock1) {
                                dmi_reqest_ct =
                                  ENUM_DMI_Request_T_Request_for_SR_data;
                              }
                              else {
                                _22_else_clock_IfBlock1 = dmi_request_int ==
                                  INT_DMI_Request_T_Request_for_switching_train_data_entry;
                                if (_22_else_clock_IfBlock1) {
                                  dmi_reqest_ct =
                                    ENUM_DMI_Request_T_Request_for_switching_train_data_entry;
                                }
                                else {
                                  _21_else_clock_IfBlock1 = dmi_request_int ==
                                    INT_DMI_Request_T_Request_for_system_version;
                                  if (_21_else_clock_IfBlock1) {
                                    dmi_reqest_ct =
                                      ENUM_DMI_Request_T_Request_for_system_version;
                                  }
                                  else {
                                    _20_else_clock_IfBlock1 = dmi_request_int ==
                                      INT_DMI_Request_T_Request_for_train_data;
                                    if (_20_else_clock_IfBlock1) {
                                      dmi_reqest_ct =
                                        ENUM_DMI_Request_T_Request_for_train_data;
                                    }
                                    else {
                                      _19_else_clock_IfBlock1 =
                                        dmi_request_int ==
                                        INT_DMI_Request_T_Request_for_train_data_view;
                                      if (_19_else_clock_IfBlock1) {
                                        dmi_reqest_ct =
                                          ENUM_DMI_Request_T_Request_for_train_data_view;
                                      }
                                      else {
                                        _18_else_clock_IfBlock1 =
                                          dmi_request_int ==
                                          INT_DMI_Request_T_Request_isolation;
                                        if (_18_else_clock_IfBlock1) {
                                          dmi_reqest_ct =
                                            ENUM_DMI_Request_T_Request_isolation;
                                        }
                                        else {
                                          _17_else_clock_IfBlock1 =
                                            dmi_request_int ==
                                            INT_DMI_Request_T_Request_to_contact_last_known_RBC;
                                          if (_17_else_clock_IfBlock1) {
                                            dmi_reqest_ct =
                                              ENUM_DMI_Request_T_Request_to_contact_last_known_RBC;
                                          }
                                          else {
                                            _16_else_clock_IfBlock1 =
                                              dmi_request_int ==
                                              INT_DMI_Request_T_Request_to_hide_geographical_information;
                                            if (_16_else_clock_IfBlock1) {
                                              dmi_reqest_ct =
                                                ENUM_DMI_Request_T_Request_to_hide_geographical_information;
                                            }
                                            else {
                                              _15_else_clock_IfBlock1 =
                                                dmi_request_int ==
                                                INT_DMI_Request_T_Request_to_hide_supervision_data;
                                              if (_15_else_clock_IfBlock1) {
                                                dmi_reqest_ct =
                                                  ENUM_DMI_Request_T_Request_to_hide_supervision_data;
                                              }
                                              else {
                                                _14_else_clock_IfBlock1 =
                                                  dmi_request_int ==
                                                  INT_DMI_Request_T_Train_running_number_entry_aborted;
                                                if (_14_else_clock_IfBlock1) {
                                                  dmi_reqest_ct =
                                                    ENUM_DMI_Request_T_Train_running_number_entry_aborted;
                                                }
                                                else {
                                                  _13_else_clock_IfBlock1 =
                                                    dmi_request_int ==
                                                    INT_DMI_Request_T_Train_data_entry_aborted;
                                                  if (_13_else_clock_IfBlock1) {
                                                    dmi_reqest_ct =
                                                      ENUM_DMI_Request_T_Train_data_entry_aborted;
                                                  }
                                                  else {
                                                    _12_else_clock_IfBlock1 =
                                                      dmi_request_int ==
                                                      INT_DMI_Request_T_Track_Ahead_Free_is_validated;
                                                    if (_12_else_clock_IfBlock1) {
                                                      dmi_reqest_ct =
                                                        ENUM_DMI_Request_T_Track_Ahead_Free_is_validated;
                                                    }
                                                    else {
                                                      _11_else_clock_IfBlock1 =
                                                        dmi_request_int ==
                                                        INT_DMI_Request_T_The_Train_Integrity_request;
                                                      if (_11_else_clock_IfBlock1) {
                                                        dmi_reqest_ct =
                                                          ENUM_DMI_Request_T_The_Train_Integrity_request;
                                                      }
                                                      else {
                                                        _10_else_clock_IfBlock1 =
                                                          dmi_request_int ==
                                                          INT_DMI_Request_T_Start_of_mission;
                                                        if (_10_else_clock_IfBlock1) {
                                                          dmi_reqest_ct =
                                                            ENUM_DMI_Request_T_Start_of_mission;
                                                        }
                                                        else {
                                                          _9_else_clock_IfBlock1 =
                                                            dmi_request_int ==
                                                            INT_DMI_Request_T_SR_data_entry_aborted;
                                                          if (_9_else_clock_IfBlock1) {
                                                            dmi_reqest_ct =
                                                              ENUM_DMI_Request_T_SR_data_entry_aborted;
                                                          }
                                                          else {
                                                            _8_else_clock_IfBlock1 =
                                                              dmi_request_int ==
                                                              INT_DMI_Request_T_Shunting_exit;
                                                            if (_8_else_clock_IfBlock1) {
                                                              dmi_reqest_ct =
                                                                ENUM_DMI_Request_T_Shunting_exit;
                                                            }
                                                            else {
                                                              _7_else_clock_IfBlock1 =
                                                                dmi_request_int ==
                                                                INT_DMI_Request_T_Shunting_entry;
                                                              if (_7_else_clock_IfBlock1) {
                                                                dmi_reqest_ct =
                                                                  ENUM_DMI_Request_T_Shunting_entry;
                                                              }
                                                              else {
                                                                _6_else_clock_IfBlock1 =
                                                                  dmi_request_int ==
                                                                  INT_DMI_Request_T_Show_tunnel_stopping_information;
                                                                if (_6_else_clock_IfBlock1) {
                                                                  dmi_reqest_ct =
                                                                    ENUM_DMI_Request_T_Show_tunnel_stopping_information;
                                                                }
                                                                else {
                                                                  _5_else_clock_IfBlock1 =
                                                                    dmi_request_int ==
                                                                    INT_DMI_Request_T_Set_VBC_request;
                                                                  if (_5_else_clock_IfBlock1) {
                                                                    dmi_reqest_ct =
                                                                      ENUM_DMI_Request_T_Set_VBC_request;
                                                                  }
                                                                  else {
                                                                    _4_else_clock_IfBlock1 =
                                                                      dmi_request_int ==
                                                                      INT_DMI_Request_T_Scroll_text_up;
                                                                    if (_4_else_clock_IfBlock1) {
                                                                      dmi_reqest_ct =
                                                                        ENUM_DMI_Request_T_Scroll_text_up;
                                                                    }
                                                                    else {
                                                                      _3_else_clock_IfBlock1 =
                                                                        dmi_request_int ==
                                                                        INT_DMI_Request_T_Scroll_text_down;
                                                                      if (_3_else_clock_IfBlock1) {
                                                                        dmi_reqest_ct =
                                                                          ENUM_DMI_Request_T_Scroll_text_down;
                                                                      }
                                                                      else {
                                                                        _2_else_clock_IfBlock1 =
                                                                          dmi_request_int ==
                                                                          INT_DMI_Request_T_Request_to_use_short_number;
                                                                        if (_2_else_clock_IfBlock1) {
                                                                          dmi_reqest_ct =
                                                                            ENUM_DMI_Request_T_Request_to_use_short_number;
                                                                        }
                                                                        else {
                                                                          _1_else_clock_IfBlock1 =
                                                                            dmi_request_int ==
                                                                            INT_DMI_Request_T_Request_to_show_supervision_data;
                                                                          if (_1_else_clock_IfBlock1) {
                                                                            dmi_reqest_ct =
                                                                              ENUM_DMI_Request_T_Request_to_show_supervision_data;
                                                                          }
                                                                          else {
                                                                            else_clock_IfBlock1 =
                                                                              dmi_request_int ==
                                                                              INT_DMI_Request_T_Request_to_show_geographical_position;
                                                                            if (else_clock_IfBlock1) {
                                                                              dmi_reqest_ct =
                                                                                ENUM_DMI_Request_T_Request_to_show_geographical_position;
                                                                            }
                                                                            else {
                                                                              dmi_reqest_ct =
                                                                                ENUM_DMI_Request_T_End_of_NTC_data_entry;
                                                                            }
                                                                          }
                                                                        }
                                                                      }
                                                                    }
                                                                  }
                                                                }
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return dmi_reqest_ct;
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** CAST_int_to_DMI_Request_DATA_Variables.c
** Generation date: 2015-11-12T10:46:57
*************************************************************$ */

