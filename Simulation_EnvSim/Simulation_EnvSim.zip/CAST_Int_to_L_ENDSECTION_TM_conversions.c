/* $*************** KCG Version 6.1.3 (build i6) ****************
** Command: s2c613 -config R:/Repositories/modeling/model/Scade/System/OBU_PreIntegrations/Testbench_Integration/Simulation_EnvSim\kcg_s2c_config.txt
** Generation date: 2015-11-12T10:46:57
*************************************************************$ */

#include "kcg_consts.h"
#include "kcg_sensors.h"
#include "CAST_Int_to_L_ENDSECTION_TM_conversions.h"

/* TM_conversions::CAST_Int_to_L_ENDSECTION */
L_ENDSECTION CAST_Int_to_L_ENDSECTION_TM_conversions(
  /* TM_conversions::CAST_Int_to_L_ENDSECTION::l_endsection_int */kcg_int l_endsection_int)
{
  /* TM_conversions::CAST_Int_to_L_ENDSECTION::l_endsection */
  static L_ENDSECTION l_endsection;
  
  l_endsection = l_endsection_int;
  return l_endsection;
}

/* $*************** KCG Version 6.1.3 (build i6) ****************
** CAST_Int_to_L_ENDSECTION_TM_conversions.c
** Generation date: 2015-11-12T10:46:57
*************************************************************$ */

